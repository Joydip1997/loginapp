package com.example.login3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public void loginClick(View view) {
        EditText userName = (EditText) findViewById(R.id.userName);
        EditText userPassword = (EditText) findViewById(R.id.userPassword);

        String password = userPassword.getText().toString();
        String admin = "admin";
        

        if (userName.getText().toString().equals("admin") && userPassword.getText().toString().equals("admin")) {

            Toast.makeText(this, "Login Aproved", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Worng Username or Password", Toast.LENGTH_SHORT).show();

        }



    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
